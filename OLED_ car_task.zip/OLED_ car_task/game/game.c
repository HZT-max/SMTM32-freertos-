#include "game.h"
#include "FreeRTOS.h"
#include "task.h"
#include "oled0561.h"
#include "encoder.h"

//******************** 初始数据 ***********************
// 全局游戏状态
u8 game_over;
#define MAX_state         20    // 同时最多存在的障碍物数量
#define SPAWN_GAP_FRAMES  40    // 每多少帧生成一个新障碍物
extern road_taskHandler;


RoadType road_1[] = {
    ROAD_BARRIER_LEFT,
    ROAD_BARRIER_RIGHT,
    ROAD_BARRIER_CENTER,
    ROAD_HOLE,
    ROAD_BUMP,
	  ROAD_HOLE,
    ROAD_BUMP,
	  ROAD_BARRIER_CENTER
};
RoadType road_2[] = {
    ROAD_BARRIER_LEFT,
//    ROAD_BARRIER_RIGHT,
//    ROAD_BARRIER_CENTER,
//    ROAD_HOLE,
//    ROAD_BUMP
};

typedef struct {
    u8 active;      // 是否启用 1=有效 0=无效
    RoadType type;  // 障碍物类型（左/右/中/坑/减速带）
    u8 page;   // OLED 页地址 (0~7)，决定“在哪条赛道”
    u8 y;      // 列坐标 (0~127)，决定“上下位置”，用于动态下落
} allstate;

allstate state[MAX_state];    //全局障碍物数组

// 根据障碍物类型选择车道（对应 OLED 页地址）
uint8_t type_page(RoadType t)
{
    switch (t) {
        case ROAD_BARRIER_LEFT:   return 0;  // 左车道
        case ROAD_BARRIER_CENTER: return 3;  // 中间车道
        case ROAD_BARRIER_RIGHT:  return 6;  // 右车道
        case ROAD_HOLE:           return 4;  // 坑洞（放中偏下）
        case ROAD_BUMP:           return 5;  // 减速带（放中偏下）
        default:                  return 2;  // 默认中间
    }
}

// 小车
typedef struct {
    u8 page;        // 页坐标（纵向，以8像素为单位）
    u8 y;        // 列坐标（横向，0~127）
    u8 w;        // 宽度（像素）
    u8 h;     	// 高度（像素）
	  u8 turn;    //车子移动数
    u8 score;   // 得分
} Car;
Car car1, car2;

// ******************** 初始化函数 ***********************

// 初始化障碍物数组
void allstate_Init(void)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        state[i].active = 0;
    }
}

void Car_Init(void)   //小车初始化
{
    car1.page = 4; car1.y = 8*14; car2.turn = 0; // 左侧
    car1.w = 6; car1.h = 8; car1.score = 50;

    car2.page = 2; car2.y = 8*14; car2.turn = 0;  // 右侧
    car2.w = 4; car2.h = 5; car2.score = 30;

    // 绘制静态小车
    OLED_DISPLAY_16x16(car1.page, car1.y,0*8);
    OLED_DISPLAY_16x16(car2.page, car2.y,0*8);
}

// 游戏初始化
void game_Init(void)
{
    allstate_Init();
	  Car_Init();
}

// ******************** 障碍物函数 ***********************

// 绘制障碍物（使用 8x8 图案）
void draw_allstate(allstate *state)
{
    if (!state->active) return;
    OLED_DISPLAY_8x8(state->page, state->y, 0);
}

// 生成一个新的障碍物（从屏幕顶端 col=0 出现）
void draw_one(RoadType t)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) {
            state[i].active = 1;         // 启用
            state[i].type = t;           // 类型
            state[i].page = type_page(t); // 车道
            state[i].y  = 0;           // 从顶端进入
            draw_allstate(&state[i]);    // 画出来
            return;                      // 只生成一个
        }
    }
}


void allstate_Update(void)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) continue;

        // 1. 清除旧位置
        OLED_DISPLAY_CLEAR_one(state[i].page, state[i].y);

        // 2. 下落一格（列坐标+1）
        if (state[i].y + 1 >= 128) {
            // 超出屏幕范围 -> 释放
            state[i].active = 0;
        } else {
            state[i].y += 1;
            // 3. 在新位置绘制
            draw_allstate(&state[i]);
        }
    }
}

// ******************** 车函数 ***********************
void car1_turn(){
	u8 w;
	while(1){
		w = ENCODER_READ();
		if(car1.turn==16){
			car1.turn=8;
			car1.page++;
		}
		if(car1.turn==0){
			car1.turn=8;
			car1.page--;
		}
		if(w==2){
			  OLED_DISPLAY_car_left_one(car1.page, car1.y,0*8);
			  OLED_DISPLAY_car_left_two(car1.page, car1.y,0*8);
			  car1.turn++;
			}
		if(w==1){
			  OLED_DISPLAY_car_left_one(car1.page, car1.y,0*8);
			  OLED_DISPLAY_car_left_two(car1.page, car1.y,0*8);
			  car1.turn--;
		}
	}
}
//void boom(){
//	u8 i;
//	for(i=0;i<MAX_state;i++){
//		if((car1.page=state[i].page&&(car1.y-8+car1.h)=(state[i].y+8))||){ //正面碰撞||
//			
//		}
//		if(){
//			
//		}
//		
//	}
//}


// ******************** 游戏主循环 ***********************
void road_type(void)
{
	  u8 frame = 0;
    u8 num = 0;
    game_over = 0;
	
    game_Init();  // 初始化游戏
	
    while(!game_over) {
        // 更新所有障碍物位置（下落）
        allstate_Update();

        // 每隔 SPAWN_GAP_FRAMES 帧，生成一个新障碍物
        if ((frame % SPAWN_GAP_FRAMES) == 0) {
            draw_one(road_1[num]);
            num++;
            if (num >= (sizeof(road_1) / sizeof(road_1[0]))) {
                game_over = 1;				
            }
        }
        // 延时控制速度（单位：ms）
        vTaskDelay(20);
        frame++;
	}
		    OLED_DISPLAY_CLEAR();                       // 清屏
    OLED_DISPLAY_8x16(2, 40, 'G');              // 显示 "Game Over"
    OLED_DISPLAY_8x16(2, 48, 'A');
    OLED_DISPLAY_8x16(2, 56, 'M');
    OLED_DISPLAY_8x16(2, 64, 'E');
    OLED_DISPLAY_8x16(4, 40, 'O');
    OLED_DISPLAY_8x16(4, 48, 'V');
    OLED_DISPLAY_8x16(4, 56, 'E');
    OLED_DISPLAY_8x16(4, 64, 'R');
	vTaskDelete(NULL);
}





