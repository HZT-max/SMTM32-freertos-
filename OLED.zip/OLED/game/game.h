#ifndef __GAME_H
#define __GAME_H

#include "stm32f10x.h"
#include "oled0561.h"

// 游戏参数定义
#define ROAD_WIDTH         100
#define ROAD_LEFT_MARGIN   14
#define ROAD_RIGHT_MARGIN  14
#define CAR_WIDTH          12
#define CAR_HEIGHT         16
#define INITIAL_SPEED      1.0f
#define MAX_SPEED          5.0f
#define ACCELERATION       0.05f

// 道路类型定义
typedef enum {
    ROAD_CLEAR,           // 无障碍直道
    ROAD_BARRIER_LEFT,    // 左侧障碍
    ROAD_BARRIER_RIGHT,   // 右侧障碍
    ROAD_BARRIER_CENTER,  // 中间障碍
    ROAD_HOLE,            // 坑洞
    ROAD_BUMP,            // 减速带
} RoadType;


// 玩家车辆状态
typedef struct {
    uint8_t x;            // 车辆x坐标(屏幕坐标系)
    uint8_t y;            // 车辆y坐标(固定为屏幕底部)
    float speed;          // 当前速度
    uint8_t width;        // 车辆宽度
    uint8_t height;       // 车辆高度
    uint8_t is_crashed;   // 是否发生碰撞
} PlayerCar;

// 游戏全局状态
typedef struct {
    PlayerCar car;
    uint16_t current_segment;  // 当前路段索引
    uint16_t segment_progress; // 在当前路段中的进度
    uint32_t score;            // 游戏分数
    u8 game_over;         // 游戏结束标志
} GameState;

// 函数声明
void allstate_Init(void);
void game_Init(void);
void draw_one(RoadType t);
void allstate_Update(void);
void road_type(void);

#endif 

