#include "game.h"
#include "FreeRTOS.h"
#include "task.h"
#include "oled0561.h"

// 全局游戏状态
u8 game_over;
#define MAX_state         20    // 同时最多存在的障碍物数量
#define SPAWN_GAP_FRAMES  40    // 每多少帧生成一个新障碍物

RoadType road_1[] = {
    ROAD_BARRIER_LEFT,
    ROAD_BARRIER_RIGHT,
    ROAD_BARRIER_CENTER,
    ROAD_HOLE,
    ROAD_BUMP,
	  ROAD_HOLE,
    ROAD_BUMP,
	  ROAD_BARRIER_CENTER
};
RoadType road_2[] = {
    ROAD_BARRIER_LEFT,
//    ROAD_BARRIER_RIGHT,
//    ROAD_BARRIER_CENTER,
//    ROAD_HOLE,
//    ROAD_BUMP
};

typedef struct {
    uint8_t active;   // 是否启用 1=有效 0=无效
    RoadType type;    // 障碍物类型（左/右/中/坑/减速带）
    uint8_t page;     // OLED 页地址 (0~7)，决定“在哪条赛道”
    uint8_t y;      // 列坐标 (0~127)，决定“上下位置”，用于动态下落
} allstate;

allstate state[MAX_state];    //全局障碍物数组


// 绘制障碍物（使用 8x8 图案）
void draw_allstate(allstate *state)
{
    if (!state->active) return;
    OLED_DISPLAY_8x8(state->page, state->y, 0);
}


// 根据障碍物类型选择车道（对应 OLED 页地址）
uint8_t type_page(RoadType t)
{
    switch (t) {
        case ROAD_BARRIER_LEFT:   return 0;  // 左车道
        case ROAD_BARRIER_CENTER: return 3;  // 中间车道
        case ROAD_BARRIER_RIGHT:  return 6;  // 右车道
        case ROAD_HOLE:           return 4;  // 坑洞（放中偏下）
        case ROAD_BUMP:           return 5;  // 减速带（放中偏下）
        default:                  return 2;  // 默认中间
    }
}


// 初始化障碍物数组
void allstate_Init(void)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        state[i].active = 0;
    }
}


// 游戏初始化
void game_Init(void)
{
    allstate_Init();
	
}


// 生成一个新的障碍物（从屏幕顶端 col=0 出现）
void draw_one(RoadType t)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) {
            state[i].active = 1;         // 启用
            state[i].type = t;           // 类型
            state[i].page = type_page(t); // 车道
            state[i].y  = 0;           // 从顶端进入
            draw_allstate(&state[i]);    // 画出来
            return;                      // 只生成一个
        }
    }
}


void allstate_Update(void)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) continue;

        // 1. 清除旧位置
        OLED_DISPLAY_CLEAR_one(state[i].page, state[i].y);

        // 2. 下落一格（列坐标+1）
        if (state[i].y + 1 >= 128) {
            // 超出屏幕范围 -> 释放
            state[i].active = 0;
        } else {
            state[i].y += 1;
            // 3. 在新位置绘制
            draw_allstate(&state[i]);
        }
    }
}

extern road_taskHandler;
void road_type(void)
{
	  u8 frame = 0;
    u8 num = 0;
    game_over = 0;
    game_Init();       // 初始化游戏
    while(!game_over) {
        // 更新所有障碍物位置（下落）
        allstate_Update();

        // 每隔 SPAWN_GAP_FRAMES 帧，生成一个新障碍物
        if ((frame % SPAWN_GAP_FRAMES) == 0) {
            draw_one(road_1[num]);
            num++;
            if (num >= (sizeof(road_1) / sizeof(road_1[0]))) {
                game_over = 1;				
            }
        }
        // 延时控制速度（单位：ms）
        vTaskDelay(20);
        frame++;
	}
		    OLED_DISPLAY_CLEAR();                       // 清屏
    OLED_DISPLAY_8x16(2, 40, 'G');              // 显示 "Game Over"
    OLED_DISPLAY_8x16(2, 48, 'A');
    OLED_DISPLAY_8x16(2, 56, 'M');
    OLED_DISPLAY_8x16(2, 64, 'E');
    OLED_DISPLAY_8x16(4, 40, 'O');
    OLED_DISPLAY_8x16(4, 48, 'V');
    OLED_DISPLAY_8x16(4, 56, 'E');
    OLED_DISPLAY_8x16(4, 64, 'R');
	vTaskDelete(NULL);
}

// ---------------- 车 ----------------





