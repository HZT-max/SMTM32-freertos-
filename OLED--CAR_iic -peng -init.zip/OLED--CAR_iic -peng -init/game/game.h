#ifndef __GAME_H
#define __GAME_H

#include "sys.h"
#include "oled0561.h"
#include "FreeRTOS.h"
#include "queue.h"

/* 基本类型兼容（如果 sys.h 已经定义 u8 可忽略） */
typedef unsigned char u8;

/* 游戏参数 */
#define MAX_STATE           20

typedef enum {
    OLED_CLEAR = 0,      // 清屏
    OLED_DRAW_car,
    OLED_DRAW_8x8,       // 画 8x8 障碍物
	  OLED_CLEAR_car,
    OLED_DRAW_16x16,     // 画 16x16 小车
    OLED_CLEAR_8x8	// 擦除某一单元（按页+列，便于移动时抹掉旧帧）
} OledType;

/* 道路类型 */
typedef enum {
    ROAD_CLEAR,
    ROAD_BARRIER_LEFT,
    ROAD_BARRIER_RIGHT,
    ROAD_BARRIER_CENTER,
    ROAD_HOLE,
    ROAD_BUMP
} RoadType;

/* 单个障碍物状态 */
typedef struct {
    u8 active;      /* 1: 有效 0: 无效 */
    RoadType type;
    u8 page;        /* OLED 页（横向） */
    u8 y;	/* OLED 列（纵向像素坐标，0..127） */
	  u8 *data;
} allstate;

/* 小车结构（保留） */
typedef struct {
    u8 page;
    u8 y;
    u8 w;
    u8 h;
    u8 turn;
    u8 score;
	  u8 *data;
} Car;

/* OLED 命令结构：由生产者发送到队列，消费端执行 */
typedef struct {
    u8 type;
    u8 page;
    u8 y;
	  u8 *data;
} Oledgame;

/* Oled 命令类型（与 oled0561 的函数对应） */
#define OLED_CMD_CLEAR        0
#define OLED_CMD_DRAW_8x8     1
#define OLED_CMD_DRAW_16x16   2
#define OLED_CMD_CLEAR_8x8    3

/* 对外全局队列句柄（在 main.c 中定义） */
extern QueueHandle_t g_xQueuePlatform;

/* 对外就绪标志（消费端会置 1） */
extern volatile u8 oled_ready;

/* 函数声明 */
void allstate_Init(void);
void game_Init(void);
void draw_one(RoadType t);
void allstate_Update(void);
void init(void *pvParameters);
void oled_game(void *pvParameters);
void road_type(void *pvParameters);
void car_task(void *pvParameters);
u8 car_state(Car *car, allstate *state);
void car_and_state(void *pvParameters);
#endif

