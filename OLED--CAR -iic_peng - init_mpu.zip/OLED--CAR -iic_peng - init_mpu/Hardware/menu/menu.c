#include "stm32f10x.h"                  // Device header
#include "oled0561.h"
#include "game.h"
#include "FreeRTOS.h"
#include "task.h"
#include "oled0561.h"
#include "encoder.h"
#include "queue.h"
#include "rtc.h"
#include "TM1640.h"
#include "MPU6050.h"
#include "semphr.h"
#include <math.h>
#include "menu.h"

u8 flag=1;  //*��һ���˵���flag�ŵ�ȫ�ֱ���,��̬�洢,���ᶪʧ����,���ԴӶ����˵������Ժ�

int menu(void)
{
	u8 menu2;

	while (1)
	{
		menu2 = menu1();//����ǰ�ǵڼ��и�������˵�,������Ȼ��ִ�ж�Ӧ�Ķ�������
		if(menu2 == 1){menu2_mpu();}
//		if(menu2 == 2){menu2_music();}
//		if(menu2 == 3){menu2_game();}
//		if(menu2 == 4){menu2_sorce();}
	}
}

void menu2_mpu(){
	OLED_DISPLAY_16x16(0,1*16,0);
	OLED_DISPLAY_16x16(0,2*16,1);
	OLED_DISPLAY_16x16(0,3*16,2);
	OLED_DISPLAY_16x16(0,4*16,3);
	OLED_DISPLAY_16x16(0,5*16,4);
	OLED_DISPLAY_16x16(0,6*16,5);
	
}

u8 menu1(void)
{
	u8 turn = 0;
	/*��ʼ��ʾ*/
	OLED_DISPLAY_16x16_turn(0,1*16,0);
	OLED_DISPLAY_16x16_turn(0,2*16,1);
	OLED_DISPLAY_16x16_turn(0,3*16,2);
	OLED_DISPLAY_16x16_turn(0,4*16,3);
	OLED_DISPLAY_16x16_turn(0,5*16,4);
	OLED_DISPLAY_16x16_turn(0,6*16,5);

	
	OLED_DISPLAY_16x16(1,1*16,6);
	OLED_DISPLAY_16x16(1,2*16,7);
	OLED_DISPLAY_16x16(1,3*16,8);
	OLED_DISPLAY_16x16(1,4*16,9);
	
	OLED_DISPLAY_16x16(2,1*16,10);
	OLED_DISPLAY_16x16(2,2*16,11);
	OLED_DISPLAY_16x16(2,3*16,12);
	OLED_DISPLAY_16x16(2,4*16,13);
	
	OLED_DISPLAY_16x16(3,1*16,14);
	OLED_DISPLAY_16x16(3,2*16,4);
	OLED_DISPLAY_16x16(3,3*16,15);
	OLED_DISPLAY_16x16(3,4*16,16);

	while(1)
	{
		turn = ENCODER_READ();
		if(turn == 1)//��һ��
		{
			flag--;
			if(flag == 0){flag = 4;}
		}
		if(turn == 2)//��һ��
		{
			flag++;
			if(flag == 5){flag = 1;}
		}
		if(turn == 3)//ȷ��
		{
			return flag;
		}
		switch(flag)
		{
			case 1:
			{
	      OLED_DISPLAY_16x16(0,1*16,0);
	      OLED_DISPLAY_16x16(0,2*16,1);
	      OLED_DISPLAY_16x16(0,3*16,2);
	      OLED_DISPLAY_16x16(0,4*16,3);
	      OLED_DISPLAY_16x16(0,5*16,4);
	      OLED_DISPLAY_16x16(0,6*16,5);

	      OLED_DISPLAY_16x16_turn(1,1*16,6);
	      OLED_DISPLAY_16x16_turn(1,2*16,7);
	      OLED_DISPLAY_16x16_turn(1,3*16,8);
	      OLED_DISPLAY_16x16_turn(1,4*16,9);
	      
	      OLED_DISPLAY_16x16(2,1*16,10);
	      OLED_DISPLAY_16x16(2,2*16,11);
	      OLED_DISPLAY_16x16(2,3*16,12);
	      OLED_DISPLAY_16x16(2,4*16,13);
	      
	      OLED_DISPLAY_16x16(3,1*16,14);
	      OLED_DISPLAY_16x16(3,2*16,4);
	      OLED_DISPLAY_16x16(3,3*16,15);
	      OLED_DISPLAY_16x16(3,4*16,16);
				break;
			}
			case 2:
			{
				//�ٴ���ʾ,����������˸����(ȷ������ǰ������״̬)
	      OLED_DISPLAY_16x16(0,1*16,0);
	      OLED_DISPLAY_16x16(0,2*16,1);
	      OLED_DISPLAY_16x16(0,3*16,2);
	      OLED_DISPLAY_16x16(0,4*16,3);
	      OLED_DISPLAY_16x16(0,5*16,4);
	      OLED_DISPLAY_16x16(0,6*16,5);

	      OLED_DISPLAY_16x16(1,1*16,6);
	      OLED_DISPLAY_16x16(1,2*16,7);
	      OLED_DISPLAY_16x16(1,3*16,8);
	      OLED_DISPLAY_16x16(1,4*16,9);
	      
	      OLED_DISPLAY_16x16_turn(2,1*16,10);
	      OLED_DISPLAY_16x16_turn(2,2*16,11);
	      OLED_DISPLAY_16x16_turn(2,3*16,12);
	      OLED_DISPLAY_16x16_turn(2,4*16,13);
	      
	      OLED_DISPLAY_16x16(3,1*16,14);
	      OLED_DISPLAY_16x16(3,2*16,4);
	      OLED_DISPLAY_16x16(3,3*16,15);
	      OLED_DISPLAY_16x16(3,4*16,16);
				break;
				
			}
			case 3:
			{
				//�ٴ���ʾ,����������˸����(ȷ������ǰ������״̬)
	      OLED_DISPLAY_16x16(0,1*16,0);
	      OLED_DISPLAY_16x16(0,2*16,1);
	      OLED_DISPLAY_16x16(0,3*16,2);
	      OLED_DISPLAY_16x16(0,4*16,3);
	      OLED_DISPLAY_16x16(0,5*16,4);
	      OLED_DISPLAY_16x16(0,6*16,5);

	      OLED_DISPLAY_16x16(1,1*16,6);
	      OLED_DISPLAY_16x16(1,2*16,7);
	      OLED_DISPLAY_16x16(1,3*16,8);
	      OLED_DISPLAY_16x16(1,4*16,9);
	      
	      OLED_DISPLAY_16x16(2,1*16,10);
	      OLED_DISPLAY_16x16(2,2*16,11);
	      OLED_DISPLAY_16x16(2,3*16,12);
	      OLED_DISPLAY_16x16(2,4*16,13);
	      
	      OLED_DISPLAY_16x16_turn(3,1*16,14);
	      OLED_DISPLAY_16x16_turn(3,2*16,4);
	      OLED_DISPLAY_16x16_turn(3,3*16,15);
	      OLED_DISPLAY_16x16_turn(3,4*16,16);
				break;
			}
		}
	}
}

