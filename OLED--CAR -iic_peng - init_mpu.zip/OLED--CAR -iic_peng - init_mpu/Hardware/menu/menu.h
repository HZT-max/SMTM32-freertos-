#ifndef __MENU_H__
#define __MENU_H__
int menu(void);
u8 menu1(void);
void menu2_mpu(void);
void menu2_music(void);
void menu2_game(void);
void menu2_sorce(void);

#endif

