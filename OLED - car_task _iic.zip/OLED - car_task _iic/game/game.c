#include "game.h"
#include "FreeRTOS.h"
#include "task.h"
#include "oled0561.h"
#include "encoder.h"
#include "queue.h"
#include "rtc.h"
//******************** 初始数据 ***********************

QueueHandle_t g_xQueuePlatform;

// 全局游戏状态
u8 game_over;

#define MAX_state         20    // 同时最多存在的障碍物数量
#define SPAWN_GAP_FRAMES  16    // 每多少帧生成一个新障碍物（改成较小值便于观察）
#define FALL_STEP         4     // 每次下落的像素数（8 = 一个 OLED 页高度）
#define FRAME_DELAY_MS    150   // 每帧延时（ms），控制下落速度

extern road_taskHandler;

allstate state[MAX_state];    //全局障碍物数组

RoadType road_1[] = {
    ROAD_BARRIER_LEFT,
    ROAD_BARRIER_RIGHT,
    ROAD_BARRIER_CENTER,
    ROAD_HOLE,
    ROAD_BUMP,
	  ROAD_HOLE,
    ROAD_BUMP,
	  ROAD_BARRIER_CENTER
};
RoadType road_2[] = {
    ROAD_BARRIER_LEFT,
//    ROAD_BARRIER_RIGHT,
//    ROAD_BARRIER_CENTER,
//    ROAD_HOLE,
//    ROAD_BUMP
};


// 根据障碍物类型选择车道（对应 OLED 页地址）
u8 type_page(RoadType t)
{
    switch (t) {
        case ROAD_BARRIER_LEFT:   return 0;  // 左车道
        case ROAD_BARRIER_CENTER: return 3;  // 中间车道
        case ROAD_BARRIER_RIGHT:  return 6;  // 右车道
        case ROAD_HOLE:           return 4;  // 坑洞（放中偏下）
        case ROAD_BUMP:           return 5;  // 减速带（放中偏下）
        default:                  return 2;  // 默认中间
    }
}

Car car1, car2;

// ******************** 初始化函数 ***********************

// 初始化障碍物数组
void allstate_Init(void)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        state[i].active = 0;
        state[i].type = ROAD_CLEAR;
        state[i].page = 0;
        state[i].y = 0;
    }
}

void Car_Init(void)   //小车初始化
{
    car1.page = 4; car1.y = 8*14; car2.turn = 8; // 左侧
    car1.w = 6; car1.h = 8; car1.score = 50;

    car2.page = 2; car2.y = 8*14; car2.turn = 8;  // 右侧
    car2.w = 4; car2.h = 5; car2.score = 30;

    // 绘制静态小车
    if (g_xQueuePlatform) {
        Oledgame m;
        m.type = OLED_DRAW_16x16;
        m.page = car1.page;
        m.y = car1.y;
        xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));

        m.page = car2.page;
        m.y = car2.y;
        xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));
    }
}

// 游戏初始化
void game_Init(void)
{
    allstate_Init();
	  Car_Init();
}

// ******************** 队列函数 ***********************
void enqueue_draw(u8 type, u8 page, u8 y)
{
	  Oledgame m;
    if (!g_xQueuePlatform) return;
    m.type = type;
    m.page = page;
    m.y = y;

    xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));
}


// ******************** 障碍物函数 ***********************

// 绘制障碍物（使用 8x8 图案）
void draw_allstate(allstate *state)
{
    if (!state || !state->active) return;
    enqueue_draw(OLED_DRAW_8x8, state->page, state->y);
}

// 生成一个新的障碍物（从屏幕顶端 col=0 出现）
void draw_one(RoadType t)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) {
            state[i].active = 1;         // 启用
            state[i].type = t;           // 类型
            state[i].page = type_page(t); // 车道
            state[i].y  = 0;           // 从顶端进入
            enqueue_draw(OLED_DRAW_8x8, state[i].page, state[i].y);    // 画出来
            return;                      // 只生成一个
        }
    }
}


void allstate_Update(void)
{
	u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) continue;

        // 1. 清除旧位置
        enqueue_draw(OLED_CLEAR_8x8, state[i].page, state[i].y);

        // 2. 下落一格（列坐标+1）
        if ((u16)state[i].y + (u16)FALL_STEP >= 128u) {
            // 超出屏幕列范围 -> 释放
            state[i].active = 0;
        } else {
            state[i].y += FALL_STEP;
            // 3) 请求在新位置绘制
            enqueue_draw(OLED_DRAW_8x8, state[i].page, state[i].y);
        }
    }
}

// ******************** 车函数 ***********************
void car_task(void *pvParameters)
{
    Oledgame m;
    u8 w;
    u8 prev_page = car1.page;  // 保存前一时刻小车所在页

    vTaskDelay(pdMS_TO_TICKS(100)); // 启动延迟

    while (!game_over) {
        // 读取编码器状态（你现有的 ENCODER_READ()）
        w = ENCODER_READ();
        if (w == 1) { // 右转
            if (car1.page < 7) car1.page++;
        } else if (w == 2) { // 左转
            if (car1.page > 0) car1.page--;
        }

        if (car1.page != prev_page) {
            // 清除旧位置的两个 8x8 区域（16x16 区域）
            m.type = OLED_CLEAR_8x8;
            m.page = prev_page;
            m.y    = car1.y;
            xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));
            m.page = prev_page + 1;
            m.y    = car1.y;
            xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));

            // 在新位置绘制 16x16 小车
            m.type = OLED_DRAW_16x16;
            m.page = car1.page;
            m.y    = car1.y;
            xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));

            prev_page = car1.page;
        }

        vTaskDelay(pdMS_TO_TICKS(50));  // 读取频率
    }
    vTaskDelete(NULL);
}




void oled_game(void *pvParameters)
{
    u8 data_page;
    u8 data_y;
    Oledgame oledgame;
	  vTaskDelay(100); //上电时等待其他器件就绪
	  OLED0561_Init(); //OLED初始化
	  OLED_DISPLAY_LIT(100);//亮度设置
    vTaskDelay(pdMS_TO_TICKS(50)); // 启动延迟，等其他初始化完成

    for (;;) {
        // 等待队列消息（无限阻塞，直到有显示请求）
        if (pdPASS == xQueueReceive(g_xQueuePlatform, &oledgame, portMAX_DELAY)) {
            data_page = oledgame.page;
            data_y = oledgame.y;

            switch (oledgame.type) {
                case OLED_CLEAR:
                    OLED_DISPLAY_CLEAR();
                    break;
                case OLED_DRAW_8x8:
                    // 第三个参数是图案索引，这里你原本把障碍物图案放在类型 0
                    OLED_DISPLAY_8x8(data_page, data_y, 0);
                    break;
                case OLED_DRAW_16x16:
                    OLED_DISPLAY_16x16(data_page, data_y, 0);
                    break;
                case OLED_CLEAR_8x8:
                    OLED_DISPLAY_CLEAR_8x8(data_page, data_y);
                    break;
                default:
                    break;
            }
        }

        if (game_over) {
            break;
        }
    }

    vTaskDelete(NULL);
}
// ******************** 游戏主循环 ***********************
void road_type(void *pvParameters)
{
    u32 frame = 0;
    u8 num = 0;
    game_over = 0;

    game_Init();       // 初始化游戏数据（包括清空 state、绘制初始小车）

    while (!game_over) {
        // 更新所有障碍物（移动并发送绘制/擦除）
        allstate_Update();

        // 定期生成新障碍物
        if ((frame % SPAWN_GAP_FRAMES) == 0) {
            draw_one(road_1[num]);
            num++;
            if (num >= (sizeof(road_1) / sizeof(road_1[0]))) {
                num = 0;   // 这里改为循环生成数组里的道路类型
            }
        }

        vTaskDelay(pdMS_TO_TICKS(FRAME_DELAY_MS)); // 控制下落速度
        frame++;
    }

    vTaskDelete(NULL);
}





