#ifndef __GAME_H
#define __GAME_H

#include "stm32f10x.h"
#include "oled0561.h"
#include "FreeRTOS.h"
#include "queue.h"
// 游戏参数定义
#define ROAD_WIDTH         100
#define ROAD_LEFT_MARGIN   14
#define ROAD_RIGHT_MARGIN  14
#define CAR_WIDTH          12
#define CAR_HEIGHT         16
#define INITIAL_SPEED      1.0f
#define MAX_SPEED          5.0f
#define ACCELERATION       0.05f

// 道路类型定义
typedef enum {
    ROAD_CLEAR,           // 无障碍直道
    ROAD_BARRIER_LEFT,    // 左侧障碍
    ROAD_BARRIER_RIGHT,   // 右侧障碍
    ROAD_BARRIER_CENTER,  // 中间障碍
    ROAD_HOLE,            // 坑洞
    ROAD_BUMP,            // 减速带
} RoadType;

typedef enum {
    OLED_CLEAR = 0,      // 清屏
    OLED_DRAW_8x8,       // 画 8x8 障碍物
    OLED_DRAW_16x16,     // 画 16x16 小车
    OLED_CLEAR_8x8	// 擦除某一单元（按页+列，便于移动时抹掉旧帧）
} OledType;

typedef struct {
    u8 active;      // 是否启用 1=有效 0=无效
    RoadType type;  // 障碍物类型（左/右/中/坑/减速带）
    u8 page;   // OLED 页地址 (0~7)，决定“在哪条赛道”
    u8 y;      // 列坐标 (0~127)，决定“上下位置”，用于动态下落
} allstate;

// 小车
typedef struct {
    u8 page;        // 页坐标（纵向，以8像素为单位）
    u8 y;        // 列坐标（横向，0~127）
    u8 w;        // 宽度（像素）
    u8 h;     	// 高度（像素）
	  u8 turn;    //车子移动数
    u8 score;   // 得分
} Car;

typedef struct {
    u8 type;
    u8 page;
    u8 y;
} Oledgame;

/* Oled 命令类型（与 oled0561 的函数对应） */
#define OLED_CMD_CLEAR        0
#define OLED_CMD_DRAW_8x8     1
#define OLED_CMD_DRAW_16x16   2
#define OLED_CMD_CLEAR_8x8    3

/* 对外全局队列句柄（在 main.c 中定义） */
extern QueueHandle_t g_xQueuePlatform;

/* 对外就绪标志（消费端会置 1） */
extern volatile u8 oled_ready;

/* 函数声明 */
void allstate_Init(void);
void game_Init(void);
void draw_one(RoadType t);
void allstate_Update(void);

void oled_game(void *pvParameters);
void road_type(void *pvParameters);
void car_task(void *pvParameters);

#endif 

