#include "sys.h"
#include "stm32f10x.h"
#include "i2c.h"
#include "rtc.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "game.h"
#include "semphr.h"
#include "TM1640.h"
#include "adc.h"

/* ȫ�ֶ��о���� game.c ���壬��Ϊ�˱�֤�ɼ�������Ҳ����һ�� extern */
extern QueueHandle_t g_xQueueOLEDform;
extern QueueHandle_t g_xQueueiicform;
extern QueueSetHandle_t g_xQueueSetInput;
TaskHandle_t xinitTaskHandle = NULL;
TaskHandle_t xtimeTaskHandle = NULL;
TaskHandle_t xoled_gameTaskHandle = NULL;
extern void init(void *pvParameters);
SemaphoreHandle_t xiicMutex;

int main(void)
{
    xiicMutex = xSemaphoreCreateMutex();

    g_xQueueOLEDform = xQueueCreate(128, sizeof(Oledgame));
	  g_xQueueiicform = xQueueCreate(32, sizeof(readiic));
	
	  g_xQueueSetInput = xQueueCreateSet(160);
	
	  xQueueAddToSet(g_xQueueOLEDform, g_xQueueSetInput);
	  xQueueAddToSet(g_xQueueiicform, g_xQueueSetInput);
	
	  xTaskCreate(init, "menu", 512, NULL, 3, &xinitTaskHandle);
	  xTaskCreate(oled_game, "oled", 512, NULL, 5, &xoled_gameTaskHandle);
	  
//	  xTaskCreate(time, "time", 128, NULL, 3, &xtimeTaskHandle);

    vTaskStartScheduler();

    /* ������е������ʾ����������ʧ�� */
    while (1) { ; }

    return 0;
}


