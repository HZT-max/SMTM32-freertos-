/*
 * game_rtos_levels_v2.c (Keil5 无标准库版 + 白色像素物体规则)
 *
 * 规则：
 *   - 1 = 白色 = 物体像素（小车/障碍物）
 *   - 0 = 黑色 = 背景（透明）
 *
 * 功能：
 *   - 关卡化障碍物
 *   - 双车逻辑
 *   - 碰撞检测
 *   - FreeRTOS 队列集事件
 *   - 帧缓冲渲染
 */

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "i2c.h"
#include "oled0561.h"

/* ======================== 内存操作函数 ======================== */
static void my_memset(void *s, int c, unsigned int n)
{
    unsigned char *p = (unsigned char *)s;
    unsigned int i;
    for(i=0; i<n; i++){
        p[i] = (unsigned char)c;
    }
}

/* ======================== OLED 帧缓冲 ======================== */
#define OLED_W 128
#define OLED_H 64
#define PAGE_H 8
#define PAGE_N (OLED_H / PAGE_H)
#define COL_OFFSET 2

static uint8_t g_fb[PAGE_N][OLED_W];
static uint8_t g_dirty[PAGE_N];

static void FB_ClearAll(void) {
    my_memset(g_fb, 0, sizeof(g_fb));      
    my_memset(g_dirty, 1, sizeof(g_dirty)); 
}
static void FB_MarkDirtyPage(uint8_t p){ if(p<PAGE_N) g_dirty[p]=1; }

/* 白色物体叠加（1=画白，0=保持原样） */
static void FB_Write8x8(uint8_t p, uint8_t col, const uint8_t *bmp) {
    uint8_t w;
    int i;
    if (p>=PAGE_N || col>=OLED_W) return;
    w = (col+8<=OLED_W)?8:(OLED_W-col);
    for(i=0;i<w;i++){
        g_fb[p][col+i] |= bmp[i];  // 白色像素叠加
    }
    FB_MarkDirtyPage(p);
}

/* OLED 刷新 */
static void OLED_FlushFB(void){
    int p,c;
    for(p=0;p<PAGE_N;p++){
        if(!g_dirty[p]) continue;
        I2C_SAND_BYTE(OLED0561_ADD, COM, (uint8_t)(0xB0 + p));
        I2C_SAND_BYTE(OLED0561_ADD, COM, (uint8_t)(0x10 + (COL_OFFSET>>4)));
        I2C_SAND_BYTE(OLED0561_ADD, COM, (uint8_t)(COL_OFFSET & 0x0F));
        for(c=0;c<OLED_W;c++) I2C_SAND_BYTE(OLED0561_ADD, DAT, g_fb[p][c]);
        g_dirty[p]=0;
    }
}

/* ======================== 精灵定义 ======================== */
/* 小车：5 行像素 */
static const uint8_t SPR_CAR[8] = {
    0xE7,
    0x42,
    0x7E,
    0x42,
    0xE7,
    0x00,
    0x00,
    0x00
};

/* 障碍物：8x8 白色方框 */
static const uint8_t SPR_BLOCK[8] = {
    0xFF,
    0x81,
    0x81,
    0x81,
    0x81,
    0x81,
    0x81,
    0xFF
};

/* ======================== 游戏对象 ======================== */
#define MAX_OBS 8
#define CELL_H 8

typedef struct {
    uint8_t alive;
    uint8_t page;
    uint8_t col;
} Obstacle;

static Obstacle obs_pool[MAX_OBS];

typedef struct {
    uint8_t page;
    uint8_t col;
} Player;

static Player player1 = {7, 20};
static Player player2 = {7, 90};

/* ======================== 游戏逻辑 ======================== */
static void render_frame(void){
    int i;
    FB_ClearAll();
    for(i=0;i<MAX_OBS;i++) if(obs_pool[i].alive)
        FB_Write8x8(obs_pool[i].page, obs_pool[i].col, SPR_BLOCK);
    FB_Write8x8(player1.page, player1.col, SPR_CAR);
    FB_Write8x8(player2.page, player2.col, SPR_CAR);
    OLED_FlushFB();
}

/* 初始化障碍物池 */
static void game_init(void){
    my_memset(obs_pool,0,sizeof(obs_pool));
}

/* 游戏主任务 */
static void vGame(void *arg){
    (void)arg;
    game_init();
    for(;;){
        render_frame();
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

/* ======================== 任务启动接口 ======================== */
void main(void){
    xTaskCreate(vGame,"GAME",256,NULL,2,NULL);
		vTaskStartScheduler();
}
