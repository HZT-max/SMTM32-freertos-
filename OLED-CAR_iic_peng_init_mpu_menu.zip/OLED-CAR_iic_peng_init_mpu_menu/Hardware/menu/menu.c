#include "stm32f10x.h"                  // Device header
#include "menu.h"
#include "game.h"
#include "MPU6050.h"
#include "adc.h"

extern vu16 ADC_DMA_IN5;
extern volatile u8 game_over;
extern volatile u8 over_shown;
extern volatile u8 car1_score;
extern volatile u8 car2_score;
u8 flag= 1;
//u8 game_running = 0;
u8 turn = 0;
u8 turn2 = 0;
u8 mpu_set = 0;
// ================= ��ʼ������ =================
void init(void *pvParameters){
	
	  u8 menu2;
	
    /* ���������ʼ������������������ǰ��ɣ� */
    RCC_Configuration();    /* ϵͳʱ�� */
    I2C_Configuration();    /* I2C ��ʼ����OLED ʹ�� */
    RTC_Config();           /* RTC����ѡ�� */
	  RELAY_Init();//�̵�����ʼ��
	
		vTaskDelay(100); //�ϵ�ʱ�ȴ�������������
	  ENCODER_Init();
	  ADC_Configuration(); //ADC��ʼ������
	  OLED0561_Init(); //OLED��ʼ��1
	  xTaskCreate(turn_light, "light", 64, NULL, 5, NULL);
		TOUCH_KEY_Init();//����������ʼ��
	  MY1690_Init(); //MP3оƬ��ʼ��
	  TM1640_Init();
    MPU6050_Init();
  	Gyro_Calibrate(); 
    Accel_Calibrate(); 
	 
		TM1640_display(0, 20);
		TM1640_display(1, 20);
		TM1640_display(2, car1_score / 10);
		TM1640_display(3, car1_score % 10);
		TM1640_display(4, 20);
		TM1640_display(5, 20);
		TM1640_display(6, car2_score / 10);
		TM1640_display(7, car2_score % 10);
	
	  while (1){
		menu2 = menu1();//����ǰ�ǵڼ��и�������˵�,������Ȼ��ִ�ж�Ӧ�Ķ�������
    vTaskDelay(100);
    if(menu2 == 1){menu2 = menu2_mpu();}
		if(menu2 == 2){menu2 = menu2_music();}
		if(menu2 == 3){menu2 = menu2_game();}
		if(menu2 == 4){menu2 = menu2_sorce();}
		vTaskDelay(100);
	  }
//	  vTaskDelete(NULL);
}
//int menu3(){
//	u8 menu3 =0;
//		menu2_game();
//	  while (1)
//	  {
//		menu3 = menu2_game();//����ǰ�ǵڼ��и�������˵�,������Ȼ��ִ�ж�Ӧ�Ķ�������
//		if(menu3 == 1){menu3 = menu3_game();}
//		if(menu3 == 2){menu3 = menu3_game();}
//		if(menu3 == 3){menu3 = menu3_game();}
//		if(menu3 == 4){menu3 = menu3_game();}
//		if(menu3 == 5){menu3 = menu3_game();}
//	  }
////	  vTaskDelete(NULL);
//}
TaskHandle_t xroad_typeTaskHandle = NULL;
TaskHandle_t xcar1_taskTaskHandle = NULL;
TaskHandle_t xcar2_taskTaskHandle = NULL;
TaskHandle_t xcar_and_stateTaskHandle = NULL;

extern TaskHandle_t xinitTaskHandle;
extern TaskHandle_t xoled_gameTaskHandle;

int menu3_game(){
	  vTaskDelay(100);
//	  vTaskSuspend(xinitTaskHandle);
//	  enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);//Ϊʲô���������Ϳ���
//     vTaskDelay(100);  //�����ټ���daley�ͺ���
	//   	OLED_DISPLAY_CLEAR();
//	  if (game_running) return 0;
//	  game_running = 1;
	  if(mpu_set == 0){
			menu2_mpu();
		}
		game_over = 0;
    over_shown = 0;
		enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
		game_Init();
//		xTaskCreate(oled_game, "oled", 512, NULL, 5, &xoled_gameTaskHandle);
    xTaskCreate(road_type, "road", 512, NULL, 4, &xroad_typeTaskHandle); // road_type ��Ҫ���ջ���ʵ���
    xTaskCreate(car1_task, "car1", 256, NULL, 3, &xcar1_taskTaskHandle);
    xTaskCreate(car2_task, "car2", 256, NULL, 3, &xcar2_taskTaskHandle);
    xTaskCreate(car_and_state, "car_state", 512, NULL, 2, &xcar_and_stateTaskHandle);
//		vTaskSuspend(xinitTaskHandle);
		while(!game_over){
			vTaskDelay(pdMS_TO_TICKS(50));
	}
		vTaskDelay(pdMS_TO_TICKS(200));
    enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
  	vTaskDelay(pdMS_TO_TICKS(500));
	  return 0;
}
extern volatile u8 car1_score;
extern volatile u8 car2_score;
int menu2_sorce(){
	u8 w_sorce = 0;
	u8 mpu_yes3 = 0;
	u8 socer11,socer12,socer21,socer22;
	vTaskDelay(100);
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
		vTaskDelay(100);
		w_sorce = ENCODER_READ();
		mpu_yes3 = mpu6050_picth();
	OLED_DISPLAY_8x16_BUFFER(2,"  Uuer1:        ");
	OLED_DISPLAY_8x16_BUFFER(5,"  Uuer2:        ");
//		socer11 = car1_score/10;
//		socer12 = car1_score%10;
//		socer21 = car2_score/10;
//		socer22 = car2_score%10;
	OLED_DISPLAY_8x16(2,10*8,car1_score/10 +0x30);
	OLED_DISPLAY_8x16(2,11*8,car1_score%10 +0x30);
	OLED_DISPLAY_8x16(5,10*8,car2_score/10 +0x30);
	OLED_DISPLAY_8x16(5,11*8,car2_score%10 +0x30);
	while(1){
		w_sorce = ENCODER_READ();
    vTaskDelay(20);		
		OLED_DISPLAY_8x16(6,15*8,mpu_yes3+0x30); 
		if(w_sorce == 3){
		enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
		vTaskDelay(20);
		break;
	  }
		mpu_yes3 = mpu6050_picth();
		if(mpu_yes3){
			enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
			vTaskDelay(80); 
			OLED_DISPLAY_8x16(6,15*8,mpu_yes3+0x30); 
			while(1){
				vTaskDelay(100);  
				mpu_yes3 = mpu6050_picth();
				OLED_DISPLAY_8x16(6,15*8,mpu_yes3+0x30); 
				if(mpu_yes3 == 0) {break;}
			}
			break;
		}
		vTaskDelay(100); 
	}
	return 0;
}


extern volatile float yaw;                /* ����ǣ��޴����ƣ������֣��᳤��Ư�ƣ� */
extern volatile float pitch;              /* �����ǣ��㣩 */
extern volatile float roll;
u8 flag2 = 1;
int menu2_game(){
	float mpu_turn2 = 0.0f;
	u8 mpu_yes2 = 0;
	u8 prev_flag2 = flag2;
	u8 menu3_ok = 0;
	prev_flag2 = 0;

	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	while(1)
	{
//		mpu6050();
		turn2 = ENCODER_READ();
		mpu_turn2 = mpu6050_roll();
		mpu_yes2 = mpu6050_picth();
		
		if(mpu_turn2 == -2){    //˲��ai
			while(1){
				mpu_turn2 = mpu6050_roll();
				if(mpu_turn2 == 0) break;
			}
			flag2 --;
			if(flag2 == 0){flag2 = 6;}
		}
		
		if(mpu_turn2 == 2){
			while(1){
				mpu_turn2 =mpu6050_roll();
				if(mpu_turn2 == 0) break;
			}
			flag2 ++;
			if(flag2 == 7){flag2 = 1;}
		}
		
		if(turn2 == 2)//��һ��
		{
			flag2 ++;
			if(flag2 == 7){flag2 = 1;}
		}
		if(turn2 == 1)//��һ��
		{
			flag2 --;
			if(flag2 == 0){flag2 = 6;}
		}
		if(turn2 == 3)//ȷ��
		{
			menu3_ok = flag2;
			prev_flag2 = 0;
			vTaskDelay(50);  //��֪��Ϊʲô����������ӳپͻز�ȥ�����µȼ���˲��ſ��ԣ�
		}
		if(mpu_yes2){
			vTaskDelay(100); 
			OLED_DISPLAY_8x16(6,15*8,mpu_yes2+0x30); 
			while(1){
				vTaskDelay(100);  
				mpu_yes2 = mpu6050_picth();
				OLED_DISPLAY_8x16(6,15*8,mpu_yes2+0x30); 
				if(mpu_yes2 == 0) {break;}
			}
			menu3_ok = flag2;
			prev_flag2 = 0;
		}
		if(menu3_ok == 1){return 0;}
		if(menu3_ok == 2){menu3_ok = menu3_game();}
		if(menu3_ok == 3){menu3_ok = menu3_game();}
		if(menu3_ok == 4){menu3_ok = menu3_game();}
		if(menu3_ok == 5){menu3_ok = menu3_game();}
		if(menu3_ok == 6){menu3_ok = menu3_game();}
    if(flag2 != prev_flag2)
      {
			prev_flag2 = flag2;
			switch(flag2)
		  {
		   case 1:{
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,1*16,NULL,28);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,2*16,NULL,29);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,3*16,NULL,29);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,18);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,20);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,6,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,6,2*16,NULL,21);
				enqueue_draw(e_OLED_DISPLAY_16x16,6,3*16,NULL,19);
				 break;
			 }
			 case 2:{
				enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,28);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,29);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,29);
				
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,2*16,NULL,18);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,20);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,6,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,6,2*16,NULL,21);
				enqueue_draw(e_OLED_DISPLAY_16x16,6,3*16,NULL,19);
				 break;
			 }
			case 3:{
				enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,28);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,29);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,29);

				enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,18);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,2*16,NULL,20);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,6,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,6,2*16,NULL,21);
				enqueue_draw(e_OLED_DISPLAY_16x16,6,3*16,NULL,19);
				break;
			}
			case 4:{
        enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,28);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,29);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,29);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,18);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,20);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,2*16,NULL,21);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,3*16,NULL,19);
				break;
			}
			case 5:{
				enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,18);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,20);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,21);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,2*16,NULL,22);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,3*16,NULL,19);
				break;
			}
			case 6:{
				enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,20);
				enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,21);
				enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,22);
				enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,19);
				
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,1*16,NULL,17);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,2*16,NULL,23);
				enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,3*16,NULL,19);
				break;
			}
		}
   }
	vTaskDelay(20);	
 }
}

int menu2_mpu(){
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	OLED_DISPLAY_16x16(0,0*16,24);
	OLED_DISPLAY_16x16(0,1*16,25);
	OLED_DISPLAY_16x16(0,2*16,0);
	OLED_DISPLAY_16x16(0,3*16,1);
	OLED_DISPLAY_16x16(0,4*16,2);
	OLED_DISPLAY_16x16(0,5*16,26);
	OLED_DISPLAY_16x16(0,6*16,27);
	vTaskDelay(2000);
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	OLED_DISPLAY_8x16(3,60,'3');
	vTaskDelay(1000);
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	OLED_DISPLAY_8x16(3,60,'2');
	vTaskDelay(1000);
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	OLED_DISPLAY_CLEAR();
	OLED_DISPLAY_8x16(3,60,'1');
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	vTaskDelay(1000);
	OLED_DISPLAY_8x16_BUFFER(3,"  Start");
	vTaskDelay(1000);
	Gyro_Calibrate(); 
  Accel_Calibrate();
	enqueue_draw(OLED_CLEAR, NULL, NULL, NULL,NULL);
	OLED_DISPLAY_8x16_BUFFER(3,"   Over");
	vTaskDelay(100);
	mpu_set = 1;
	return 0;
}


int menu1(void)
{
	u8 mpu_yes = 0;
	u8 prev_flag = flag;
	float mpu_turn = 0.0f;
	prev_flag = 0;
//  flag = 2;
	while(1)
	{
		turn = ENCODER_READ();
		mpu_turn = mpu6050_roll();
		mpu_yes = mpu6050_picth();
		
		if(mpu_turn == -2.0f){    //˲��ai
			while(1){
				mpu_turn =mpu6050_roll();
				if(mpu_turn == 0) break;
			}
			flag--;
			if(flag == 0){flag = 4;}
		}
		if(mpu_turn == 2.0f){
			while(1){
				mpu_turn =mpu6050_roll();
				if(mpu_turn == 0) break;
			}
			flag++;
			if(flag == 5){flag = 1;}
		}
		if(turn == 2)//��һ��
		{
			flag++;
			if(flag == 5){flag = 1;}
		}
		if(turn == 1)//��һ��
		{
			flag--;
			if(flag == 0){flag = 4;}
		}
		if(turn == 3)//ȷ��
		{
			turn = 0;
			return flag;
		}
		if(mpu_yes){  //һ������λ��ִ�У�������ʶ��
			vTaskDelay(50);   //����������������λ���Ӹ���ʱ�ͺ���
			enqueue_draw(OLED_8x16,6,15*8,NULL,mpu_yes+0x30);  //��������ʶ�𣩰����ȡ��Ҳ���У��ѵ��ǲ��۲��
			vTaskDelay(50);
			while(1){
    //�����ټ���ʱ�ͺ��ˡ�����666
				mpu_yes = mpu6050_picth();
				enqueue_draw(OLED_8x16,6,15*8,NULL,mpu_yes+0x30); //����ʶ�𣩶����������ע�͵�����û����
				vTaskDelay(100);
        if(mpu_yes == 0) {break;}
			}
			turn = 0;
			return flag;
		}
    if(flag != prev_flag)
        {
					prev_flag = flag;
		  switch(flag)
		  {
		  	case 1:
//void enqueue_draw(u8 type, u8 page, u8 y,u8 *data,u8 num)					
		  	{	enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,1*16,NULL,0);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,2*16,NULL,1);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,3*16,NULL,2);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,4*16,NULL,3);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,5*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,0,6*16,NULL,5);    
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,6);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,7);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,8);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,4*16,NULL,9);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,1*16,NULL,10);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,2*16,NULL,11);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,3*16,NULL,12);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,4*16,NULL,13);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,14);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,15);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,4*16,NULL,16);
					break;
		  	}
		  	case 2:
		  	{
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,0);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,1);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,2);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,4*16,NULL,3);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,5*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,6*16,NULL,5);
      
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,1*16,NULL,6);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,2*16,NULL,7);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,3*16,NULL,8);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,2,4*16,NULL,9);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,1*16,NULL,10);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,2*16,NULL,11);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,3*16,NULL,12);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,4*16,NULL,13);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,14);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,15);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,4*16,NULL,16);
		  		break;
		  	}
		  	case 3:
		  	{
					enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,0);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,1);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,2);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,4*16,NULL,3);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,5*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,6*16,NULL,5);
      
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,6);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,7);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,8);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,4*16,NULL,9);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,1*16,NULL,10);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,2*16,NULL,11);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,3*16,NULL,12);
	        enqueue_draw(e_OLED_DISPLAY_16x16,6,4*16,NULL,13);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,1*16,NULL,14);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,2*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,3*16,NULL,15);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,4,4*16,NULL,16);
		  		break;
		  	}
		  	case 4:
		  	{
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,1*16,NULL,0);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,2*16,NULL,1);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,3*16,NULL,2);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,4*16,NULL,3);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,5*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16,0,6*16,NULL,5);
      
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,1*16,NULL,6);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,2*16,NULL,7);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,3*16,NULL,8);
	        enqueue_draw(e_OLED_DISPLAY_16x16,2,4*16,NULL,9);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,1*16,NULL,10);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,2*16,NULL,11);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,3*16,NULL,12);
	        enqueue_draw(e_OLED_DISPLAY_16x16_turn,6,4*16,NULL,13);
	        
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,1*16,NULL,14);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,2*16,NULL,4);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,3*16,NULL,15);
	        enqueue_draw(e_OLED_DISPLAY_16x16,4,4*16,NULL,16);
		  		break;
		  	}
//				delay_ms(1);
			}
		}
				vTaskDelay(20);
	}
}


