#ifndef __MENU_H__
#define __MENU_H__

void init(void *pvParameters);
int menu1(void);
int menu2_mpu(void);
int menu2_game(void);
int menu2_music(void);
int menu2_sorce(void);
int menu2_game(void);
int menu3_game(void);
//int menu3(void);

#endif
