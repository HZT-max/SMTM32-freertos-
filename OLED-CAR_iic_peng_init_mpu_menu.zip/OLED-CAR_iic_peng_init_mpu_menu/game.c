#include "game.h"
#include "stm32f10x.h"  // ??STM32??????

// ??????
GameState game_state;

const RoadSegment race_track[] = {
    {ROAD_CLEAR, 60, 0},
    {ROAD_BARRIER_LEFT, 20, 3},
    {ROAD_CLEAR, 30, 0},
    {ROAD_BARRIER_CENTER, 25, 4},
    {ROAD_CLEAR, 40, 0},
    {ROAD_BARRIER_RIGHT, 20, 3},
    {ROAD_HOLE, 15, 5},
    {ROAD_CLEAR, 50, 0},
    {ROAD_BUMP, 10, 2},
};

#define TRACK_LENGTH (sizeof(race_track) / sizeof(RoadSegment))

// ?????????????(??sprintf)
static void uint32_to_str(uint32_t value, char* str) {
    uint8_t i = 0;
    uint32_t temp = value;
    
    // ??????
    do {
        i++;
        temp /= 10;
    } while(temp);
    
    // ?????????
    str[i] = '\0';
    do {
        str[--i] = '0' + (value % 10);
        value /= 10;
    } while(value);
}

// ?????
void Game_Init(void) {
    // ?????
    game_state.car.x = 64 - CAR_WIDTH/2;
    game_state.car.y = 56;
    game_state.car.speed = INITIAL_SPEED;
    game_state.car.width = CAR_WIDTH;
    game_state.car.height = CAR_HEIGHT;
    game_state.car.is_crashed = 0;
    
    // ???????
    game_state.current_segment = 0;
    game_state.segment_progress = 0;
    game_state.score = 0;
    game_state.game_over = 0;
}

// ??????
static void draw_road_slice(uint8_t y, RoadType type, uint8_t severity) {
    // ??????
    OLED_DISPLAY_8x16(y/8, ROAD_LEFT_MARGIN/8, '|');
    OLED_DISPLAY_8x16(y/8, (ROAD_LEFT_MARGIN + ROAD_WIDTH)/8, '|');
    
    // ???????????
    switch(type) {
			uint8_t i;
        case ROAD_CLEAR:
            break;
            
        case ROAD_BARRIER_LEFT:
            for(i = 0; i < severity; i++) {
                OLED_DISPLAY_8x16(y/8, (ROAD_LEFT_MARGIN + i)/8, '#');
            }
            break;
            
        case ROAD_BARRIER_RIGHT:
            for(i = 0; i < severity; i++) {
                OLED_DISPLAY_8x16(y/8, (ROAD_LEFT_MARGIN + ROAD_WIDTH - i)/8, '#');
            }
            break;
            
        case ROAD_BARRIER_CENTER:
            for(i = 0; i < severity; i++) {
                OLED_DISPLAY_8x16(y/8, (ROAD_LEFT_MARGIN + ROAD_WIDTH/2 - severity/2 + i)/8, '#');
            }
            break;
            
        case ROAD_HOLE:
            for(i = 0; i < severity; i++) {
                OLED_DISPLAY_8x16(y/8, (ROAD_LEFT_MARGIN + ROAD_WIDTH/2 - severity/2 + i)/8, ' ');
            }
            break;
            
        case ROAD_BUMP:
            for(i = 0; i < ROAD_WIDTH; i += 2) {
                OLED_DISPLAY_8x16(y/8, (ROAD_LEFT_MARGIN + i)/8, '-');
            }
            break;
    }
}


static void draw_car(void) {
    uint8_t page = game_state.car.y / 8;
    uint8_t col = game_state.car.x / 8;
    

    OLED_DISPLAY_8x16(page, col, '[');
    OLED_DISPLAY_8x16(page, col + 1, '=');
    OLED_DISPLAY_8x16(page, col + 2, ']');
    

    OLED_DISPLAY_8x16(page + 1, col, '[');
    OLED_DISPLAY_8x16(page + 1, col + 1, 'o');
    OLED_DISPLAY_8x16(page + 1, col + 2, ']');
}


void Game_Render(void) {
	char final_score[16];
    OLED_DISPLAY_CLEAR();
    

    uint16_t current_segment = game_state.current_segment;
    uint16_t progress = game_state.segment_progress;
    

    for(uint8_t y = 0; y < 8; y++) {
        uint16_t virtual_y = (7 - y) * game_state.car.speed;
        

        while(virtual_y >= progress && current_segment < TRACK_LENGTH) {
            virtual_y -= progress;
            current_segment++;
            if(current_segment < TRACK_LENGTH) {
                progress = race_track[current_segment].length;
            }
        }
        

        if(current_segment < TRACK_LENGTH) {
            draw_road_slice(y, race_track[current_segment].type, race_track[current_segment].severity);
        }
    }
    
    // ??????
    if(!game_state.car.is_crashed) {
        draw_car();
    }
    
    // ???? - ???????????sprintf
    char score_str[16] = "Score:";
    char num_str[10];
    uint32_to_str(game_state.score, num_str);
    
    // ?????
    uint8_t i = 6; // "Score:"???
    char* p = num_str;
    while(*p) {
        score_str[i++] = *p++;
    }
    score_str[i] = '\0';
    
    OLED_DISPLAY_8x16_BUFFER(0, score_str);
    
    // ??????,????????
    if(game_state.game_over) {
        OLED_DISPLAY_8x16_BUFFER(3, "GAME OVER");
        
        char final_score[16] = "Score:";
        uint32_to_str(game_state.score, num_str);
        
        i = 6;
        p = num_str;
        while(*p) {
            final_score[i++] = *p++;
        }
        final_score[i] = '\0';
        
        OLED_DISPLAY_8x16_BUFFER(4, final_score);
        OLED_DISPLAY_8x16_BUFFER(6, "Press to restart");
    }
}

// ??????
void Game_Update(void) {
    if(game_state.game_over) return;
    
    // ??????
    game_state.segment_progress += (uint16_t)game_state.car.speed;
    
    // ??????????????
    while(game_state.segment_progress >= race_track[game_state.current_segment].length && 
          game_state.current_segment < TRACK_LENGTH - 1) {
        game_state.segment_progress -= race_track[game_state.current_segment].length;
        game_state.current_segment++;
    }
    
    // ????
    game_state.score += (uint32_t)game_state.car.speed;
    
    // ????
    if(Game_CheckCollision()) {
        game_state.car.is_crashed = 1;
        game_state.game_over = 1;
    }
}

// ????
uint8_t Game_CheckCollision(void) {
    RoadSegment current_segment = race_track[game_state.current_segment];
    
    switch(current_segment.type) {
        case ROAD_CLEAR:
            return 0;
            
        case ROAD_BARRIER_LEFT:
            return (game_state.car.x < ROAD_LEFT_MARGIN + current_segment.severity);
            
        case ROAD_BARRIER_RIGHT:
            return (game_state.car.x + game_state.car.width > 
                   ROAD_LEFT_MARGIN + ROAD_WIDTH - current_segment.severity);
            
        case ROAD_BARRIER_CENTER:
            return (game_state.car.x < ROAD_LEFT_MARGIN + ROAD_WIDTH/2 + current_segment.severity/2 &&
                   game_state.car.x + game_state.car.width > ROAD_LEFT_MARGIN + ROAD_WIDTH/2 - current_segment.severity/2);
            
        case ROAD_HOLE:
            return (game_state.car.x + game_state.car.width/2 >= 
                   ROAD_LEFT_MARGIN + ROAD_WIDTH/2 - current_segment.severity/2 &&
                   game_state.car.x + game_state.car.width/2 <= 
                   ROAD_LEFT_MARGIN + ROAD_WIDTH/2 + current_segment.severity/2);
            
        case ROAD_BUMP:
            game_state.car.speed *= 0.8;
            if(game_state.car.speed < INITIAL_SPEED) {
                game_state.car.speed = INITIAL_SPEED;
            }
            return 0;
    }
    
    return 0;
}

// ????
void Game_HandleInput(uint8_t left, uint8_t right) {
    if(game_state.game_over) {
        if(left || right) {
            Game_Init();
        }
        return;
    }
    
    if(left && game_state.car.x > ROAD_LEFT_MARGIN + 2) {
        game_state.car.x -= 2;
    }
    if(right && game_state.car.x + game_state.car.width < ROAD_LEFT_MARGIN + ROAD_WIDTH - 2) {
        game_state.car.x += 2;
    }
    
    if((left || right) && game_state.car.speed < MAX_SPEED) {
        game_state.car.speed += ACCELERATION;
    }
}