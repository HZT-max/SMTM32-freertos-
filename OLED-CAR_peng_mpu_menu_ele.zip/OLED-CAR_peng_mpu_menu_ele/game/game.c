#include "game.h"
#include "FreeRTOS.h"
#include "task.h"
#include "oled0561.h"
#include "encoder.h"
#include "queue.h"
#include "rtc.h"
#include "TM1640.h"
#include "MPU6050.h"
#include "semphr.h"
#include <math.h>
#include "key.h"
#include "NVIC.h"
#include "flash.h"
// 全局游戏状态
volatile u8 game_over = 0;
volatile u8 over_shown = 0;
volatile u16 car1_score;
volatile u16 car2_score;
         
#define MAX_state         20    // 同时最多存在的障碍物数量
#define SPAWN_GAP_FRAMES  7    // 每多少帧生成一个新障碍物（改成较小值便于观察）
#define FALL_STEP         6     // 每次下落的像素数（8 = 一个 OLED 页高度）
#define FRAME_DELAY_MS    120   // 每帧延时（ms），控制下落速度

QueueHandle_t g_xQueueOLEDform;
QueueHandle_t g_xQueueiicform;
QueueSetHandle_t g_xQueueSetInput;

Car car1, car2;

RoadType road_1[] = {
  ROAD_0,
	ROAD_7,
	ROAD_4,
	ROAD_2,
  ROAD_6,
	ROAD_3,
	ROAD_7,
	ROAD_1,
	ROAD_5,
	ROAD_7,
  ROAD_3,
  ROAD_0,
	ROAD_7,
  ROAD_4,
  ROAD_5,
  ROAD_4,
	ROAD_7,
	ROAD_1,
  ROAD_5,
	ROAD_5,
  ROAD_6
};

allstate state[MAX_state];    // 全局障碍物数组

// 根据障碍物类型选择车道（对应 OLED 页地址）
uint8_t type_page(RoadType t)
{
    switch (t) {
        case ROAD_0:   return 0;  // 左车道
        case ROAD_3:   return 3;  // 中间车道
        case ROAD_6:   return 6;  // 右车道
        case ROAD_4:   return 4;  // 坑洞（放中偏下）
        case ROAD_5:   return 5;  // 减速带（放中偏下）
			  case ROAD_2:    return 2;
			  case ROAD_1:    return 1;
			  case ROAD_7:    return 7;
    }
}

void allstate_Init(void)
{
    u8 i;
    for (i=0; i<MAX_state; i++) {
        state[i].active = 0;
        state[i].type = ROAD_CLEAR;
        state[i].page = 0;
        state[i].y = 0;
    }
}

// 小车初始化（只初始化结构与队列绘制请求，不直接操作 OLED）
extern u8 car_16x16[];

void car_sorce_init(){
	u16 a,b;
	a = FLASH_R(0x0801f000);
	b = FLASH_R(0x0801f000 + 4);
	if(a==b){
	car1_score = 30;
	car2_score = 30;}
	else{
	car1_score = a;
  car2_score = b;}
}

void Car_Init(void)
{
    // 左车（car1）
    car1.page = 4;
    car1.y = 8*14;
    car1.w = 6;
    car1.h = 8;
    car1.turn = 5;

    // 右车（car2）
    car2.page = 2;
    car2.y = 8*14;
    car2.w = 4;
    car2.h = 6;
    car2.turn = 6;

    // 使用队列请求绘制两辆静态小车（这样 OLED 的 I2C 统一由 oled_task 处理）
    if (g_xQueueOLEDform) {
        Oledgame m;
        m.type = OLED_DRAW_car;
        m.page = car1.page;
        m.y = car1.y;
			  m.data = &car_16x16[0*32];
			  m.num = NULL;
        xQueueSend(g_xQueueOLEDform, &m, pdMS_TO_TICKS(5));

			  m.type = OLED_DRAW_car;
        m.page = car2.page;
        m.y = car2.y;
		   	m.data = &car_16x16[1*32];
			  m.num = NULL;
        xQueueSend(g_xQueueOLEDform, &m, pdMS_TO_TICKS(5));
    }
}

void game_Init(void)
{
    allstate_Init();
    Car_Init();
	  car1_score+=20;
		car2_score+=20;
}

//  向显示队列发一条命令（不阻塞过久）
void enqueue_draw(u8 type, u8 page, u8 y,u8 *data,u8 num)
{
	  Oledgame m;
    m.type = type;
    m.page = page;
    m.y = y;
	  m.data = data;
	  m.num = num;
    // 等待 2 ms 写入队列，避免长期阻塞发送任务
    xQueueSend(g_xQueueOLEDform, &m, pdMS_TO_TICKS(2));
}

// 绘制单个已启用的障碍（通过队列，不直接操作 I2C）
void draw_allstate(allstate *s)
{
    if (!s || !s->active) return;
    enqueue_draw(OLED_DRAW_8x8, s->page, s->y, s->data,NULL);
}

// 生成一个新的障碍物（从屏幕顶端 col=0 出现） —— 只负责状态设置并请求绘制
void draw_one(RoadType t)
{
    u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) {
            state[i].active = 1;            // 启用
            state[i].type = t;              // 类型
            state[i].page = type_page(t);   // 车道（页）
            state[i].y  = 0;                // 从顶端（列=0）进入
            // 通过队列请求初始绘制（避免直接操作 OLED）
					  vTaskDelay(8);
            enqueue_draw(OLED_DRAW_8x8, state[i].page, state[i].y ,state[i].data,NULL);
            return;
        }
    }
}

// 更新所有障碍物位置（下落逻辑）
// 说明：为了避免 I2C 大量随机写，
// 我们采取“先发送清除旧位置命令，再改变 y，再发送绘制新位置命令”的流程。
// 下落步长由 FALL_STEP 决定（此处建议 8 像素 = 1 页）
void allstate_Update(void)
{
    u8 i;
	  for (i=0; i<MAX_state; i++) {
			state[i].active = 1;
		}
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) continue;   // 跳过未激活的条目
        vTaskDelay(2);
        // 1) 清除当前单元（请求 OLED 擦除对应页/列的 8 字节）
        enqueue_draw(OLED_CLEAR_8x8, state[i].page, state[i].y ,state[i].data,NULL);

        // 2) 下落
        if ((u16)state[i].y + (u16)FALL_STEP >= 128u) {
            // 超出屏幕列范围 -> 释放
            state[i].active = 0;
        } else {
            state[i].y += FALL_STEP;
					  vTaskDelay(5);
            // 3) 请求在新位置绘制
            enqueue_draw(OLED_DRAW_8x8, state[i].page, state[i].y ,state[i].data,NULL);
        }
    }
}

// =============== 小车任务 ===============
//小车翻页移动
u8 out1_up[16];
u8 out1_low[16];
u8 up1[16];
u8 low1[16];

u8 out2_up[16];
u8 out2_low[16];
u8 up2[16];
u8 low2[16];

void car1_task(void *pvParameters)
{
//    Oledgame m;
    u8 w=0;
	  u8 j,i;
	
    vTaskDelay(pdMS_TO_TICKS(100)); // 启动延迟
  	w=ENCODER_READ();   //1是右转，2是左转，3是按下
	  for(j=0;j<16;j++){ 
		up1[j]  = car_16x16[j];
    low1[j] = car_16x16[16+j];
		}
	  while(1){
			if (game_over) break;
		  w=ENCODER_READ();
      if (w==1 && car1.turn!=0) {  //右转
				for(i=0;i<16;i++){      
        out1_up[i] = (u8)( ( ( (unsigned int) up1[i] >> 1 ) ) | ( (unsigned int)low1[i] << 7) );
				out1_low[i] = (u8)( (unsigned int)low1[i]>>1 );
				up1[i]  = out1_up[i];
				low1[i] = out1_low[i];
			  }
				enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data,NULL);
			  enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, out1_up,NULL);
			  enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, out1_low,NULL);
			  car1.turn--;
				w = 0;
          }
		   if (w==2 && car1.turn!=10) {     //左转
				 for(i=0;i<16;i++){
				  out1_up[i] = (u8)( (unsigned int)up1[i]<<1 );
          out1_low[i] = (u8)( ( ( (unsigned int)low1[i] << 1 ) ) | ( (unsigned int)up1[i] >> 7) );
					up1[i]  = out1_up[i];
				  low1[i] = out1_low[i];
				 }
				  enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data,NULL);
			    enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, out1_up,NULL);
			  	enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, out1_low,NULL);
			    car1.turn++;
				  w = 0;
          }
			 if(car1.turn==0 && w==1){     //右转到另一页
					car1.turn=7;
				  for(j=0;j<16;j++){ 
			 		up1[j]  = (u8)( (unsigned int)car_16x16[j]<<2 );
          low1[j] = (u8)( ( ( (unsigned int)car_16x16[j+16] << 2 ) ) | ( (unsigned int)car_16x16[j] >> 6) );
					}
				enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data,NULL);
				car1.page--;
			  enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, up1,NULL);
			  enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, low1,NULL);			
		    }
		  if(car1.turn==10 && w==2){     //左转到另一页
			    car1.turn=3;
					for(j=0;j<16;j++){ 
            up1[j]  = (u8)( ( ( (unsigned int) car_16x16[j] >> 2 ) ) | ( (unsigned int)car_16x16[16+j] << 6) );
				    low1[j] = (u8)( (unsigned int)car_16x16[16+j]>>2 );
	      	}
        enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data,NULL);
				car1.page++;
			  enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, up1,NULL);
			  enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, low1,NULL);					
		    }
			vTaskDelay(pdMS_TO_TICKS(10));
		}
		vTaskDelete(NULL);
}
u8 v = 1;
void car2_task(void *pvParameters)
{
//    Oledgame m;
    float mpu = 0.0f;   //1是右转，2是左转，3是按下
	  u8 j,i;
	  u8 mpu_Z;
	
    vTaskDelay(pdMS_TO_TICKS(100)); // 启动延迟
//		RELAY_Init(); 
//    MPU6050_Init();
//	  Gyro_Calibrate();              /* 陀螺零偏（LSB） */
//		Accel_Calibrate();             /* 安装角度偏移（°） */
	  for(j=0;j<16;j++){ 
		up2[j]  = car_16x16[32+j];
    low2[j] = car_16x16[16+32+j];
		}
		mpu = mpu6050();
	  while(1){
			if (game_over) break;
		  mpu = mpu6050();
			mpu_Z = (int)fabsf(mpu);
			if((unsigned int)mpu_Z >1){
				v=1;
			}
			if((unsigned int)mpu_Z >2){
				v=2;
			}
			if((unsigned int)mpu_Z >3){
				v=3;
			}
			if ((mpu<-0.5f) && car2.turn!=0) {     //右转
				for(i=0;i<16;i++){      
				out2_up[i] = (u8)( ( ( (unsigned int) up2[i] >> 1 ) ) | ( (unsigned int)low2[i] << 7) );
				out2_low[i] = (u8)( (unsigned int)low2[i]>>1 );
				up2[i]  = out2_up[i];
				low2[i] = out2_low[i];
				}
				enqueue_draw(OLED_CLEAR_car,car2.page, car2.y,car2.data,NULL);
				enqueue_draw(OLED_DRAW_car ,car2.page, car2.y, out2_up,NULL);
				enqueue_draw(OLED_DRAW_car ,car2.page+1, car2.y, out2_low,NULL);
				car2.turn--;
					}
			 if ((mpu>0.5f) && car2.turn!=12) {  //左转
				 for(i=0;i<16;i++){
					out2_up[i] = (u8)( (unsigned int)up2[i]<<1 );
					out2_low[i] = (u8)( ( ( (unsigned int)low2[i] << 1 ) ) | ( (unsigned int)up2[i] >> 7) );
					up2[i]  = out2_up[i];
					low2[i] = out2_low[i];
				 }
					enqueue_draw(OLED_CLEAR_car,car2.page, car2.y,car2.data,NULL);
					enqueue_draw(OLED_DRAW_car ,car2.page, car2.y, out2_up,NULL);
					enqueue_draw(OLED_DRAW_car ,car2.page+1, car2.y, out2_low,NULL);
					car2.turn++;
					}
			 if(car2.turn==0 && (mpu<-0.5f)){     //右转到另一页
					car2.turn=7;
					for(j=0;j<16;j++){
					up2[j]  = (u8)( (unsigned int)car_16x16[32+j]<<1 );
					low2[j] = (u8)( ( ( (unsigned int)car_16x16[32+j+16] << 1 ) ) | ( (unsigned int)car_16x16[32+j] >> 7) );
					}
				enqueue_draw(OLED_CLEAR_car,car2.page, car2.y,car2.data,NULL);
				car2.page--;                   
				enqueue_draw(OLED_DRAW_car ,car2.page, car2.y, up2,NULL);
				enqueue_draw(OLED_DRAW_car ,car2.page+1, car2.y, low2,NULL);			
				}
			if(car2.turn==12 && (mpu>0.5f)){         //左转到另一页
					car2.turn=5;
					for(j=0;j<16;j++){
						up2[j]  = (u8)( ( ( (unsigned int) car_16x16[32+j] >> 1 ) ) | ( (unsigned int)car_16x16[16+32+j] << 7) );
						low2[j] = (u8)( (unsigned int)car_16x16[16+32+j]>>1 );
					}
				enqueue_draw(OLED_CLEAR_car,car2.page, car2.y,car2.data,NULL);
				car2.page++;
				enqueue_draw(OLED_DRAW_car ,car2.page, car2.y, up2,NULL);
				enqueue_draw(OLED_DRAW_car ,car2.page+1, car2.y, low2,NULL);			
		    }
			mpu = 0.0f;
			vTaskDelay(100-30*v);
		}
		vTaskDelete(NULL);
}

// =============== OLED 显示任务 ===============
void oled_game(void *pvParameters)
{
	  TickType_t now,start,wait,eletime,wait2,start2;
    u8 data_page,data_y;
	  u8 *data_data;
	  u16 data_light;
	  u8 data_add,data_bdd;
	  u16 data_num;
	  u8 *data_where;
	  u8 w_time;
    TickType_t timeout = pdMS_TO_TICKS(10000); // 超时时间 3000ms
	  TickType_t timeout2 = pdMS_TO_TICKS(10000); // 超时时间 3000ms
    Oledgame oledgame;
	  readiic iic;
	  QueueSetMemberHandle_t xQueueHandle = NULL;
    start = xTaskGetTickCount();
    while(1){           // 等待队列消息（无限阻塞，直到有显示请求）
			now = xTaskGetTickCount();
			if ((now - start) >= timeout) {
         wait = 0;}
			else {
            wait = timeout - (now - start);}
			xQueueHandle = xQueueSelectFromSet(g_xQueueSetInput, wait);
       if(xQueueHandle){	
        if (xQueueHandle == g_xQueueOLEDform) {
					  xQueueReceive(g_xQueueOLEDform, &oledgame, portMAX_DELAY);
            data_page = oledgame.page;
            data_y = oledgame.y;
					  data_data = oledgame.data;
					  data_num = oledgame.num;
					  start = xTaskGetTickCount();
            switch (oledgame.type){
                case OLED_CLEAR:
                    OLED_DISPLAY_CLEAR();
                    break;
                case OLED_DRAW_8x8:
                    // 第三个参数是图案索引，这里你原本把障碍物图案放在类型 0
                    OLED_DISPLAY_8x8(data_page, data_y, 0);
                    break;
                case OLED_CLEAR_8x8:
                    OLED_DISPLAY_CLEAR_8x8(data_page, data_y);
                    break;
								case OLED_DRAW_car:
                    OLED_DISPLAY_car(data_page, data_y,data_data);
                    break;
								case OLED_CLEAR_car:
								   	OLED_DISPLAY_CLEAR_car(data_page,data_y);
								    break;
								case OLED_DRAW_over:
									  OLED_DISPLAY_CLEAR();
									  OLED_DISPLAY_8x16_BUFFER(3,"   GAME OVER");
								    over_shown = 1;
								    break;
								case time:
									  vTaskDelay(pdMS_TO_TICKS(1));
								    break;
								case e_OLED_DISPLAY_16x16_turn:
									OLED_DISPLAY_16x16_turn(data_page,data_y,data_num);
								  break;
								case e_OLED_DISPLAY_16x16:
									OLED_DISPLAY_16x16(data_page,data_y,data_num);
								  break;
								case OLED_8x16:
									OLED_DISPLAY_8x16(data_page,data_y,data_num);
								  break;
                default:
                    break;
            }
        }
				if (xQueueHandle == g_xQueueiicform) {
					xQueueReceive(g_xQueueiicform, &iic, portMAX_DELAY);
					data_add = iic.add;
					data_bdd = iic.bdd;
					data_where = iic.where;
					data_num = iic.num;
					data_light = iic.data;
					
					switch (iic.type){
						case READ:
					    I2C_READ_BUFFER(data_add, data_bdd, data_where, data_num); //读出连续的数据地址，包括了加速度和陀螺仪共12字节
						    break;
						case light_turn:
					    OLED_DISPLAY_LIT(data_light);
						    break;
						default:
                break;
				}
			}
				vTaskDelay(pdMS_TO_TICKS(1));
    }
			 else {
				 start2 = xTaskGetTickCount();
				 w_time = 0;
        OLED_DISPLAY_CLEAR();
				 while(1){
				eletime = xTaskGetTickCount();
				w_time = mpu6050_roll2();
				OLED_DISPLAY_8x16(6,10*8,w_time+0x30);
				vTaskDelay(pdMS_TO_TICKS(2));  // 使用FreeRTOS延时函数
		    if(w_time == 1){
					OLED_DISPLAY_CLEAR();
          start = xTaskGetTickCount();
						break;
					}
			  if ((eletime - start2) >= timeout2) {
         wait2 = 0;}
			  else {
            wait2 = timeout2 - (eletime - start2);}
				if(wait2 == 0){
          vTaskDelay(pdMS_TO_TICKS(50));				
					OLED_DISPLAY_8x16_BUFFER(3,"     SLEEP      ");
					vTaskDelay(pdMS_TO_TICKS(50));	
//					--- 关键：短暂禁止 SysTick，执行 WFI ---------
//             目的：避免 SysTick 立即把 CPU 唤醒，从而只让外部你允许的中断把芯片唤醒。
//             * 强烈注意：禁用 SysTick 会让 FreeRTOS 丢失 tick，生产环境请使用 tickless idle。
//             ---------------------------------------------------*/
          __DSB();
          __ISB();
          /* 禁用 SysTick，避免它把 CPU 唤醒 */
          SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
          __DSB();
          __ISB();

          /* 进入低功耗等待，只有能唤醒 STOP/深度睡眠 的外部中断会起作用。
             如果你只希望 EXTIx 唤醒，确保其他中断在这时没有被使能。 */
          __WFI();

          /* 唤醒后，恢复 SysTick，使能内核继续运行 */
          __DSB();
          __ISB();
          SysTick->VAL = 0; /* 清计数器，避免重进立即中断（视平台可选） */
          SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
          __DSB();
          __ISB();

          /* 简单同步：重置 start（注意：这并不是严格的 tick 修正）。
             如果你需要精确修正，请使用 tickless-idle（vPortSuppressTicksAndSleep）。 */
          start = xTaskGetTickCount();
					vTaskDelay(pdMS_TO_TICKS(50));
					OLED_DISPLAY_CLEAR();
					start = xTaskGetTickCount();
					break;
				}
			}
			 }
//			  if (game_over && over_shown) {
//           break;
//        }
				vTaskDelay(pdMS_TO_TICKS(1));
	}
//		vTaskDelete(NULL);
}

// =============== 游戏主循环（road） ===============
extern TaskHandle_t xoled_gameTaskHandle;
extern TaskHandle_t xroad_typeTaskHandle;
extern TaskHandle_t xcar1_taskTaskHandle;
extern TaskHandle_t xcar2_taskTaskHandle;
extern TaskHandle_t xcar_and_stateTaskHandle;

void road_type(void *pvParameters)
{   
    u32 frame = 0;
    u8 num = 0;
    game_over = 0;

//    game_Init();       // 初始化游戏数据（包括清空 state、绘制初始小车）

    while (1) {
        allstate_Update();
        vTaskDelay(8);
        // 只有在还没生成完 road_1 数组项时才生成
        if ((frame % SPAWN_GAP_FRAMES ) == 0 && num < MAX_state) {
            draw_one(road_1[num]);
            num++;
        }

        // 如果已经生成完所有预定障碍且当前没有任何激活的障碍，则结束
        if (num >= MAX_state) {
            u8 i; 
            u8 any_active = 0;
            for (i = 0; i < MAX_state; ++i) {
                if (state[i].active) { any_active = 1; break; }
            }
            if (!any_active) {
                // 可以在这里发送一次 GAME OVER 的显示请求（使用明确的 over 图案）
              enqueue_draw(OLED_DRAW_over, 3, 64, NULL,NULL);
              vTaskDelay(pdMS_TO_TICKS(200));
            }
        }
				if(over_shown){							
				game_over = 1;
				break;
				  }
        vTaskDelay(pdMS_TO_TICKS(FRAME_DELAY_MS)); // 控制下落速度
				frame++;
    }

    vTaskDelay(pdMS_TO_TICKS(500));
    vTaskDelete(NULL);
}

u8 car1_state(Car *car1, allstate *state) {
    u8 car1_x = car1->page * 8;
    u8 car1_y = car1->y;
    u8 state_x = state->page * 8;
    u8 state_y = state->y;
    return (car1_x + car1->turn <state_x + 8 &&
            car1_x + car1->w + car1->turn > state_x &&
            car1_y < state_y + 8 &&
            car1_y + car1->h > state_y);
}

u8 car2_state(Car *car2, allstate *state) {
    u8 car2_x = car2->page * 8;
    u8 car2_y = car2->y;
    u8 state_x = state->page * 8;
    u8 state_y = state->y;
    return (car2_x + car2->turn < state_x + 8 &&
            car2_x + car2->w + car2->turn > state_x &&
            car2_y < state_y + 8 &&
            car2_y + car2->h > state_y);
}
void car_and_state(void *pvParameters) {
	  u8 i;
    vTaskDelay(pdMS_TO_TICKS(50));
    while (1) {
			if (game_over) break;
			for (i = 0; i < MAX_state; i++) {
				if (!state[i].active) continue;         //避免一瞬间识别完
				if (car1_state(&car1, &state[i])){
						car1_score--;
						TM1640_display(2, car1_score / 10);
						TM1640_display(3, car1_score % 10);
				}
			}
      for (i = 0; i < MAX_state; i++) {
				if (!state[i].active) continue; 
				if (car2_state(&car2, &state[i])){
						car2_score--;
						TM1640_display(6, car2_score / 10);
						TM1640_display(7, car2_score % 10);
				}
			}
			vTaskDelay(pdMS_TO_TICKS(200));
    }
		vTaskDelete(NULL);
}



