#ifndef __NVIC_H
#define __NVIC_H	 
#include "sys.h"


extern u8 INT_MARK;//�жϱ�־λ


void KEY_INT_INIT (void);

#endif
