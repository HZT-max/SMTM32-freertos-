#ifndef __GAME_H
#define __GAME_H

#include "stm32f10x.h"
#include "oled0561.h"

// ??????
#define ROAD_WIDTH         100
#define ROAD_LEFT_MARGIN   14
#define ROAD_RIGHT_MARGIN  14
#define CAR_WIDTH          12
#define CAR_HEIGHT         16
#define INITIAL_SPEED      1.0f
#define MAX_SPEED          5.0f
#define ACCELERATION       0.05f

// ??????
typedef enum {
    ROAD_CLEAR,           // ?????
    ROAD_BARRIER_LEFT,    // ????
    ROAD_BARRIER_RIGHT,   // ????
    ROAD_BARRIER_CENTER,  // ????
    ROAD_HOLE,            // ??
    ROAD_BUMP,            // ???
} RoadType;

// ??????
typedef struct {
    RoadType type;        // ????
    uint16_t length;      // ????(????)
    uint8_t severity;     // ????/?????
} RoadSegment;

// ??????
typedef struct {
    uint8_t x;            // ??x??(?????)
    uint8_t y;            // ??y??(???????)
    float speed;          // ????
    uint8_t width;        // ????
    uint8_t height;       // ????
    uint8_t is_crashed;   // ??????
} PlayerCar;

// ??????
typedef struct {
    PlayerCar car;
    uint16_t current_segment;  // ??????
    uint16_t segment_progress; // ?????????
    uint32_t score;            // ????
    uint8_t game_over;         // ??????
} GameState;

// ????
void Game_Init(void);
void Game_Update(void);
void Game_Render(void);
uint8_t Game_CheckCollision(void);
void Game_HandleInput(uint8_t left, uint8_t right);

#endif /* __GAME_H */