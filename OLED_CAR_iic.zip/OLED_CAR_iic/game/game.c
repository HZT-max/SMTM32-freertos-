#include "game.h"
#include "FreeRTOS.h"
#include "task.h"
#include "oled0561.h"
#include "encoder.h"
#include "queue.h"
#include "rtc.h"

// 全局游戏状态
u8 game_over = 0;

#define MAX_state         20    // 同时最多存在的障碍物数量
#define SPAWN_GAP_FRAMES  16    // 每多少帧生成一个新障碍物（改成较小值便于观察）
#define FALL_STEP         4     // 每次下落的像素数（8 = 一个 OLED 页高度）
#define FRAME_DELAY_MS    150   // 每帧延时（ms），控制下落速度

QueueHandle_t g_xQueuePlatform;
Car car1, car2;

RoadType road_1[] = {
    ROAD_BARRIER_LEFT,
    ROAD_BARRIER_RIGHT,
    ROAD_BARRIER_CENTER,
    ROAD_HOLE,
    ROAD_BUMP,
    ROAD_HOLE,
    ROAD_BUMP,
    ROAD_BARRIER_CENTER
};

allstate state[MAX_state];    // 全局障碍物数组

// 根据障碍物类型选择车道（对应 OLED 页地址）
uint8_t type_page(RoadType t)
{
    switch (t) {
        case ROAD_BARRIER_LEFT:   return 0;  // 左车道
        case ROAD_BARRIER_CENTER: return 3;  // 中间车道
        case ROAD_BARRIER_RIGHT:  return 6;  // 右车道
        case ROAD_HOLE:           return 4;  // 坑洞（放中偏下）
        case ROAD_BUMP:           return 5;  // 减速带（放中偏下）
        default:                  return 2;
    }
}

// ================= 初始化函数 =================
// 初始化障碍物数组
void allstate_Init(void)
{
    u8 i;
    for (i=0; i<MAX_state; i++) {
        state[i].active = 0;
        state[i].type = ROAD_CLEAR;
        state[i].page = 0;
        state[i].y = 0;
    }
}

// 小车初始化（只初始化结构与队列绘制请求，不直接操作 OLED）
void Car_Init(void)
{
    // 左车（car1）
    car1.page = 4;
    car1.y = 8*14;
    car1.w = 6;
    car1.h = 8;
    car1.turn = 6  ;
    car1.score = 50;

//    // 右车（car2）
//    car2.page = 2;
//    car2.y = 8*14;
//    car2.w = 4;
//    car2.h = 5;
//    car2.turn = 3;
//    car2.score = 30;

    // 使用队列请求绘制两辆静态小车（这样 OLED 的 I2C 统一由 oled_task 处理）
    if (g_xQueuePlatform) {
        Oledgame m;
        m.type = OLED_DRAW_16x16;
        m.page = car1.page;
        m.y = car1.y;
        xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));

//        m.page = car2.page;
//        m.y = car2.y;
//        xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));
    }
}

void game_Init(void)
{
    allstate_Init();
    Car_Init();
}

// Helper: 向显示队列发一条命令（不阻塞过久）
static void enqueue_draw(u8 type, u8 page, u8 y,u8 *data)
{
	  Oledgame m;
    if (!g_xQueuePlatform) return;
    m.type = type;
    m.page = page;
    m.y = y;
	  m.data = data;
    // 等待 10 ms 写入队列，避免长期阻塞发送任务
    xQueueSend(g_xQueuePlatform, &m, pdMS_TO_TICKS(10));
}

// 绘制单个已启用的障碍（通过队列，不直接操作 I2C）
// 旧代码曾直接调用 OLED_DISPLAY_8x8，这里改为通过队列一致化显示控制
void draw_allstate(allstate *s)
{
    if (!s || !s->active) return;
    enqueue_draw(OLED_DRAW_8x8, s->page, s->y, s->data);
}

// 生成一个新的障碍物（从屏幕顶端 col=0 出现） —— 只负责状态设置并请求绘制
void draw_one(RoadType t)
{
    u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) {
            state[i].active = 1;            // 启用
            state[i].type = t;              // 类型
            state[i].page = type_page(t);   // 车道（页）
            state[i].y  = 0;                // 从顶端（列=0）进入
            // 通过队列请求初始绘制（避免直接操作 OLED）
            enqueue_draw(OLED_DRAW_8x8, state[i].page, state[i].y ,state[i].data);
            return;
        }
    }
}

// 更新所有障碍物位置（下落逻辑）
// 说明：为了避免 I2C 大量随机写，
// 我们采取“先发送清除旧位置命令，再改变 y，再发送绘制新位置命令”的流程。
// 下落步长由 FALL_STEP 决定（此处建议 8 像素 = 1 页）
void allstate_Update(void)
{
    u8 i;
    for (i=0; i<MAX_state; i++) {
        if (!state[i].active) continue;   // 跳过未激活的条目

        // 1) 清除当前单元（请求 OLED 擦除对应页/列的 8 字节）
        enqueue_draw(OLED_CLEAR_8x8, state[i].page, state[i].y ,state[i].data);

        // 2) 下落
        if ((u16)state[i].y + (u16)FALL_STEP >= 128u) {
            // 超出屏幕列范围 -> 释放
            state[i].active = 0;
        } else {
            state[i].y += FALL_STEP;
            // 3) 请求在新位置绘制
            enqueue_draw(OLED_DRAW_8x8, state[i].page, state[i].y ,state[i].data);
        }
    }
}

// =============== 小车任务 ===============
//哈哈，最难的一个逻辑，小车翻页计数
extern u8 car_16x16[];
u8 out1[16];
u8 out2[16];
u8 up[16];
u8 low[16];

void car_task(void *pvParameters)
{
//    Oledgame m;
    u8 w=0;
	  u8 j,i;
    u8 prev_page = car1.page;  // 保存前一时刻小车所在页

    vTaskDelay(pdMS_TO_TICKS(100)); // 启动延迟
  	w=ENCODER_READ();   //1是右转，2是左转，3是按下
	  for(j=0;j<16;j++){ 
		up[j]  = car_16x16[j];
    low[j] = car_16x16[16+j];
		}
	  while(1){
		  w=ENCODER_READ();
      if (w==1 && car1.turn!=12) {  //右转
				for(i=0;i<16;i++){      
        out1[i] = (u8)( ( ( (unsigned int) up[i] >> 1 ) ) | ( (unsigned int)low[i] << 7) );
				out2[i] = (u8)( (unsigned int)low[i]>>1 );
				up[i]  = out1[i];
				low[i] = out2[i];
			  }
				enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data);
			  enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, out1);
			  enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, out2);
			  car1.turn++;
          }
		   if (w==2 && car1.turn!=0) {     //左转
				 for(i=0;i<16;i++){
				  out1[i] = (u8)( (unsigned int)up[i]<<1 );
          out2[i] = (u8)( ( ( (unsigned int)low[i] << 1 ) ) | ( (unsigned int)up[i] >> 7) );
					up[i]  = out1[i];
				  low[i] = out2[i];
				 }
				  enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data);
			    enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, out1);
			  	enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, out2);
			    car1.turn--;
          }
			 if(car1.turn==12 && w==1){     //右转到另一页
					car1.turn=4;
				  for(j=0;j<16;j++){ 
			 		up[j]  = (u8)( (unsigned int)car_16x16[j]<<2 );
          low[j] = (u8)( ( ( (unsigned int)car_16x16[j+16] << 2 ) ) | ( (unsigned int)car_16x16[j] >> 6) );
					}
				enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data);
				car1.page--;
			  enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, up);
			  enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, low);			
		    }
		  if(car1.turn==0 && w==2){     //左转到另一页
			    car1.turn=8 ;
					for(j=0;j<16;j++){ 
            up[j]  = (u8)( ( ( (unsigned int) car_16x16[j] >> 2 ) ) | ( (unsigned int)car_16x16[16+j] << 6) );
				    low[j] = (u8)( (unsigned int)car_16x16[16+j]>>2 );
	      	}
        enqueue_draw(OLED_CLEAR_car,car1.page, car1.y,car1.data);
				car1.page++;
			  enqueue_draw(OLED_DRAW_car ,car1.page, car1.y, up);
			  enqueue_draw(OLED_DRAW_car ,car1.page+1, car1.y, low);					
		    }
		}
    vTaskDelete(NULL);
}

// =============== OLED 显示任务 ===============
// 注意：必须是 void fn(void *pvParameters) 的签名 —— 这里是关键修正
void oled_game(void *pvParameters)
{
    u8 data_page;
    u8 data_y;
	  u8 *data_data;
	
    Oledgame oledgame;
	
	  vTaskDelay(100); //上电时等待其他器件就绪
	  OLED0561_Init(); //OLED初始化
	  OLED_DISPLAY_LIT(100);//亮度设置
    vTaskDelay(pdMS_TO_TICKS(50)); // 启动延迟，等其他初始化完成

    for (;;) {
        // 等待队列消息（无限阻塞，直到有显示请求）
        if (pdPASS == xQueueReceive(g_xQueuePlatform, &oledgame, portMAX_DELAY)) {
            data_page = oledgame.page;
            data_y = oledgame.y;
					  data_data = oledgame.data;
            switch (oledgame.type) {
                case OLED_CLEAR:
                    OLED_DISPLAY_CLEAR();
                    break;
                case OLED_DRAW_8x8:
                    // 第三个参数是图案索引，这里你原本把障碍物图案放在类型 0
                    OLED_DISPLAY_8x8(data_page, data_y, 0);
                    break;
                case OLED_DRAW_16x16:
                    OLED_DISPLAY_16x16(data_page, data_y, 0);
                    break;
                case OLED_CLEAR_8x8:
                    OLED_DISPLAY_CLEAR_8x8(data_page, data_y);
                    break;
								case OLED_DRAW_car:
                    OLED_DISPLAY_car(data_page, data_y,data_data);
                    break;
								case OLED_CLEAR_car:
								   	OLED_DISPLAY_CLEAR_car(data_page,data_y);
                default:
                    break;
            }
        }

        if (game_over) {
            break;
        }
    }

    vTaskDelete(NULL);
}

// =============== 游戏主循环（road） ===============
// 说明：本函数设计为任务入口（void fn(void*))
// 请用 xTaskCreate(road_type, "road", ...) 来创建它
void road_type(void *pvParameters)
{
    u32 frame = 0;
    u8 num = 0;
    game_over = 0;

    game_Init();       // 初始化游戏数据（包括清空 state、绘制初始小车）

    while (!game_over) {
        // 更新所有障碍物（移动并发送绘制/擦除）
        allstate_Update();

        // 定期生成新障碍物
        if ((frame % SPAWN_GAP_FRAMES) == 0) {
            draw_one(road_1[num]);
            num++;
            if (num >= (sizeof(road_1) / sizeof(road_1[0]))) {
                num = 0;   // 这里改为循环生成数组里的道路类型
            }
        }

        vTaskDelay(pdMS_TO_TICKS(FRAME_DELAY_MS)); // 控制下落速度
        frame++;
    }

    vTaskDelete(NULL);
}





